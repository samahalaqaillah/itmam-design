
/*
start  function for time to show pic
*/

$(document).ready(function(){

$(".carousel").carousel({
    
    interval:8000
 }); 
 });





/*
end of function 
*/

/*
start function to stop slider on mouse over 
*/


$(function() {
    var interval = setInterval( slideSwitch, 10000 );

    $('#slideshow').hover(function() {
        clearInterval(interval);
    }, function() {
        interval = setInterval( slideSwitch, 10000 );
    });
});



/*
end function to stop slider on mouse over 

*/




















